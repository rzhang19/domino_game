var class_serializable_transform =
[
    [ "SerializableTransform", "class_serializable_transform.html#a49fbe7422e148135690437c07cba3a2c", null ],
    [ "ToString", "class_serializable_transform.html#acaa8021952074a73c617527b0ad19448", null ],
    [ "_position", "class_serializable_transform.html#aad2371ff67245a7facfd0ec248cc655a", null ],
    [ "_rotation", "class_serializable_transform.html#ad48de8312e285eb0cc284ec42e851fba", null ],
    [ "_scale", "class_serializable_transform.html#ac81d05106456b53ed12772f75e1439b6", null ]
];