var dir_37090b53233a6d7ffa0775f23efbb51e =
[
    [ "DesignPatterns", "dir_0bac08b62e3de1b9a228a0871ed03f4e.html", "dir_0bac08b62e3de1b9a228a0871ed03f4e" ]
];