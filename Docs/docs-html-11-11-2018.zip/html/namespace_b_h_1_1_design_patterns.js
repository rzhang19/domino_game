var namespace_b_h_1_1_design_patterns =
[
    [ "GameEvent", "class_b_h_1_1_design_patterns_1_1_game_event.html", "class_b_h_1_1_design_patterns_1_1_game_event" ],
    [ "GameEvent1Arg", "class_b_h_1_1_design_patterns_1_1_game_event1_arg.html", "class_b_h_1_1_design_patterns_1_1_game_event1_arg" ],
    [ "GameEventInt", "class_b_h_1_1_design_patterns_1_1_game_event_int.html", null ],
    [ "GameEventInvoker", "class_b_h_1_1_design_patterns_1_1_game_event_invoker.html", "class_b_h_1_1_design_patterns_1_1_game_event_invoker" ],
    [ "GameEventsListener", "class_b_h_1_1_design_patterns_1_1_game_events_listener.html", null ],
    [ "GameEventString", "class_b_h_1_1_design_patterns_1_1_game_event_string.html", null ],
    [ "Pool", "class_b_h_1_1_design_patterns_1_1_pool.html", "class_b_h_1_1_design_patterns_1_1_pool" ],
    [ "PooledMonobehaviour", "class_b_h_1_1_design_patterns_1_1_pooled_monobehaviour.html", "class_b_h_1_1_design_patterns_1_1_pooled_monobehaviour" ],
    [ "PoolPreparer", "class_b_h_1_1_design_patterns_1_1_pool_preparer.html", null ],
    [ "Singleton", "class_b_h_1_1_design_patterns_1_1_singleton.html", "class_b_h_1_1_design_patterns_1_1_singleton" ]
];