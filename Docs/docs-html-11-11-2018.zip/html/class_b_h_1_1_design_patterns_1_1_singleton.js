var class_b_h_1_1_design_patterns_1_1_singleton =
[
    [ "OnDestroy", "class_b_h_1_1_design_patterns_1_1_singleton.html#a5e2d6cb53a958ea93b1ac901806ec821", null ],
    [ "Instance", "class_b_h_1_1_design_patterns_1_1_singleton.html#a3105674401256fcc1d4a1a35fa6c4cc8", null ]
];