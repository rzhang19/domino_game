var dir_0bac08b62e3de1b9a228a0871ed03f4e =
[
    [ "GameEvent", "dir_8952c5eca3cdfafcc288fbf1ab15d984.html", "dir_8952c5eca3cdfafcc288fbf1ab15d984" ],
    [ "ObjectPool", "dir_5e2b02dafe5080adfef7227de06e2084.html", "dir_5e2b02dafe5080adfef7227de06e2084" ],
    [ "Singleton.cs", "_singleton_8cs.html", [
      [ "Singleton", "class_b_h_1_1_design_patterns_1_1_singleton.html", "class_b_h_1_1_design_patterns_1_1_singleton" ]
    ] ]
];