var searchData=
[
  ['bh',['BH',['../namespace_b_h.html',1,'']]],
  ['designpatterns',['DesignPatterns',['../namespace_b_h_1_1_design_patterns.html',1,'BH']]]
];
